$(document).ready(function () {
    $("#backup").click(function () {
        // alert(3232)
       
            $('html,body').animate({scrollTop: 0},'slow');
        
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})
$(document).ready(function () {
    $("#backabout").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#About").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})
$(document).ready(function () {
    $("#backabout1").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#About").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})

$(document).ready(function () {
    $("#backabout2").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#Resume").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})
$(document).ready(function () {
    $("#backabout3").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#WORKS").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})
$(document).ready(function () {
    $("#backabout5").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#Concat").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})
$(document).ready(function () {
    $("#backabout4").click(function () {
        // alert(3232)
        $('html,body').animate({
            scrollTop: $("#banner").offset().top
        }, 'slow');
        // $('#Works').animate({ scrollTop: 0 }, 2000)
    })


})

// $(document).ready(function() {
//     // alert(123)
//     $(window).scroll(function(){
//         if ($(this).scrollTop()) {
//             $('nav').addClass('sticky')
//         }else{
//             $('nav').removeClass('sticky')
//         }
//     })

// })